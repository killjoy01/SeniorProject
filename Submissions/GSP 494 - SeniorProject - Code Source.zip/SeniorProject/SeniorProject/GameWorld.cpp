#include "GameWorld.h"
#include "Player.h"
#include <fstream>
#include <string>
#include <vector>
using namespace std;

GameWorld::GameWorld()
{
	currentLevel = 0;

}

GameWorld::GameWorld(const GameWorld & g)
{
}

GameWorld::~GameWorld()
{
	for(int i = 0; i < levels.size(); ++i)
		levels.empty();
}

void GameWorld::init()
{
	GameLevel * newLevel = new GameLevel();
	levels.push_back(*newLevel);
	Active = 0;
	/*	
				
			main_sprite.InitialVelocity = 0.0f;
			ground[0] = new The_Sprite(graphics, new Texture2D("/Application/resources/ground.png", false), new Vector3((960.0F / 2.0F), (544.0F / 2.0f), 0.0F),
										 new Vector3(1.0f, 1.0f, 1.0f), 0.0f);							                                                        
			ground[0].position = new Vector3(ground[0].position.X - (ground[0].Width / 2), ground[0].position.Y + (ground[0].Height / 2), 0.0f);
			ground[0].Update ();
			ground[1] = new The_Sprite(graphics, new Texture2D("/Application/resources/ground.png", false), new Vector3((960.0F / 2.0F), (544.0F / 2.0f), 0.0F),
										 new Vector3(1.0f, 1.0f, 1.0f), 0.0f);							                                                        
			ground[1].position = new Vector3(ground[0].rect.max.X, ground[1].position.Y + (ground[1].Height / 2), 0.0f);
			ground[1].Update ();
			platform = new The_Sprite(graphics, new Texture2D("/Application/resources/platform.png", false), new Vector3((960.0F / 2.0F), (544.0F / 2.0f), 0.0F),
										 new Vector3(1.0f, 1.0f, 1.0f), 0.0f);
			platform.position = new Vector3(600.0f, ground[0].position.Y - platform.Height, 0.0f);
			platform.Update ();
		*/
}

GameWorld & GameWorld::operator = (const GameWorld & g)
{
	return * this;
}

Player * GameWorld::getPlayer()
{
	return &player;
}

void GameWorld::setPlayer(int i, Player * p)
{
}

int GameWorld::getActive()
{
	return Active;
}

void GameWorld::setActive(int a)
{
	Active = a;
}

void GameWorld::addLevel(GameLevel gl)
{
	levels.push_back(gl);
}

void GameWorld::loadFromFile(IDirect3DDevice9* a_d, IDirect3DTexture9* a_t, char * filename)
{
	ifstream file;
	file.open(filename);
	The_Sprite * sprite = new The_Sprite;
	float x, y;
	int width, height, list;
	string imagefilename;
	file >> x >> y >> width >> height >> list;
	sprite->setTexture(a_t);
	sprite->setPosition(D3DXVECTOR3(x, y, 0.0f));
	sprite->setWidth(width);
	sprite->setHeight(height);
	sprite->setRect();
	sprite->setScalex(1.0f);
	sprite->setScaley(1.0f);
	sprite->setRotation(0.0f);
	if (list == 0)
	{
		//ground.push_back(sprite);
	}
	else
	{
		//platform.push_back(sprite);
	}
}

//The_Sprite * GameWorld::getSprite(int list, int i)
//{
//}

void GameWorld::clearVectors()
{
	
}

void GameWorld::draw(IDirect3DDevice9* a_device, ID3DXSprite* a_sprite, D3DXMATRIX * a_world)
{
	levels[Active].draw(a_device, a_sprite, a_world);
}

GameLevel * GameWorld::getLevel(int i)
{
	return &levels[i];
}