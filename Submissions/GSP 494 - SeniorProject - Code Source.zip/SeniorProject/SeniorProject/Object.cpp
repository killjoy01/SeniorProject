#pragma once

#include "Object.h"

Object::Object()
{}