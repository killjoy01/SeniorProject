#pragma once

class Power
{
private:
	int ID;

public:
	Power();
	int getID();
	void setID(int);
};