#pragma once

#include "sprite.h"

class Object : public The_Sprite
{
private:
	bool solid;
	//int type;
public:
	Object();
};